package com.cdh.campcar.Recycler;

import android.view.View;

public interface ItemClickListener {
    void onItemClick(View v, int position);
}
